書式
===
**&lt;Begin word>** ref=**&lt;File path>**|**&lt;Configuration value>**[convert="base64"]**&lt;End word>**

依存
===
| 参照対象        | 参照記述例   | 依存先初期値      |
| --------------- | ------------ | ----------------- |
| ローカルファイル| ./sub.html   | 参照ファイル      |
| コンフィグ値    | #[main]title | コンフィグファイル|
| シェルスクリプト| >ls          | なし              |

[目次に戻る](contents.md)
