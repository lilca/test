Deference of `sed` command
===
I designed `tir` as no complication (regular expression) as possible.

If you prefer `tir`, please use and improvement(e.g. Pull Requests).

[back to Contents](contents.md)
