目次
===
* [インストール](install_jp.md)
* [構文](syntax_jp.md)
* [ヘルプモード](help-mode_jp.md)
* 事例
  * [1. HTMLファイルの中に、HTMLファイルを挿入する](example1_jp.md)
  * [2. 複数ファイル＆ネスティング（入れ子）](example2_jp.md)
  * [3. コンフィグ値の挿入](example3_jp.md)
* [`sed`コマンドとの違い](deference-of-sed-command_jp.md)

-[メモ](note_jp.md)

[README_jpに戻る](../README_jp.md)
