構文
===
```
$ tir <input file> [-o <output file>] [-y] [-makefile]
      [-bw <beginning word>] [-ew <ending word>]
      [-cfg <config file>] [-h]
```
```
$ tirc <target directory>
```

[目次に戻る](contents_jp.md)
