Format
===
**&lt;Begin word>** ref=**&lt;File path>**|**&lt;Configuration value>**[convert="base64"]**&lt;End word>**

Dependency
===
| Reference target  | Example      | Default        |
| ----------- | ------------ | -------------- |
| Local file  | ./sub.html   | Reference file |
| Config value| #[main]title | Config file    |
| Shell script| >ls          | -none-         |

[back to Contents](contents.md)
