Install
===
```
$ sudo make install
```

[back to Contents](contents.md)
